import React from 'react'

const page: React.FC = () => {
  return (
    <div>page</div>
  )
}

export default page