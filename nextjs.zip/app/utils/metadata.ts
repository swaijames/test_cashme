// app/utils/metadata.ts
export const metadata = {
    title: "CashMe Tanzania",
    description: "An online marketplace for Invoice Discounting",
  };
  