// pages/faq/page.tsx

import React from 'react';
import FAQComponent from '../../components/FAQ';

const FAQPage: React.FC = () => (
    <div>
        <FAQComponent />
    </div>
);

export default FAQPage;
