
import React from 'react'
import ContactUs from '@/components/ContactUs';

const page: React.FC = () => {
    return (
        <div><ContactUs /></div>
    )
}

export default page