import OurTeam from '@/components/OurTeam'
import React from 'react'
import Teams from '@/components/Teams';


const page: React.FC = () => {
    return (
        <div>
            <Teams />
            <OurTeam />

        </div>
    )
}

export default page