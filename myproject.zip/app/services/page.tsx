import ServiceSection from '@/components/ServiceSection'
import Servicespage from '@/components/Servicespage'
import React from 'react'

const page: React.FC = () => {
    return (

        <div>
            <Servicespage />
            <ServiceSection />
        </div>
    )
}

export default page