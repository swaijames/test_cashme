import React from 'react'
import CareerSection from '../../components/Career';

const page: React.FC = () => {
    return (
        <div>
            <CareerSection/>
        </div>
    )
}

export default page